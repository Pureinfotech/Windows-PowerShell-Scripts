# Clear screen and Welcome Screen with Warning
Clear-Host
    Write-Host "======================================================================================" -ForegroundColor Cyan
    Write-Host " Disable Microsoft Defender Antivirus script (beta) by Pureinfotech                   " -ForegroundColor Yellow
    Write-Host " Full guide https://pureinfotech.com/disable-defender-antivirus-permanently-windows-11" -ForegroundColor Yellow
    Write-Host "======================================================================================" -ForegroundColor Cyan
    Write-Host "`nThis script allows you to disable the Windows 11 antivirus."
    Write-Host "You can also use it to re-enable the AV again as needed."
    Write-Host "Script has been tested on version 24H2 and 23H2."
    Write-Host "Please follow the instructions carefully." -ForegroundColor Cyan
    Write-Host "You can always abort the process as shown in the script."
    Write-Host "Warning: This tool is offered as-is without any guarantee." -ForegroundColor Red
    Write-Host "Use it at your own risk. Create a full backup before proceeding." -ForegroundColor Red
    Write-Host "--------------------------------------------------`n" -ForegroundColor Cyan

# Option to cancel the script
$response = Read-Host "Do you want to proceed with the script or cancel? (Type 'Proceed' or 'Cancel')"
if ($response -eq "Cancel") {
    Write-Host "Script canceled by the user." -ForegroundColor Yellow
    exit
}

# Check if Microsoft Defender Antivirus is disabled in the registry
$defenderKey = "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender"
$disableAntivirus = Get-ItemProperty -Path $defenderKey -Name "DisableAntiSpyware" -ErrorAction SilentlyContinue

if ($disableAntivirus.DisableAntiSpyware -eq 1) {
    Write-Host "Microsoft Defender Antivirus is already disabled." -ForegroundColor Yellow
    $response = Read-Host "Do you want to undo the changes and re-enable it? (Y/N or 'Cancel')"
    if ($response -eq "Cancel") {
        Write-Host "Script canceled by the user." -ForegroundColor Yellow
        exit
    } elseif ($response -eq "Y") {
        # Enable Microsoft Defender by removing the registry keys silently
        Remove-ItemProperty -Path $defenderKey -Name "DisableAntiSpyware" -ErrorAction SilentlyContinue | Out-Null
        Remove-ItemProperty -Path $defenderKey -Name "DisableRealtimeMonitoring" -ErrorAction SilentlyContinue | Out-Null
        Remove-ItemProperty -Path $defenderKey -Name "DisableAntiVirus" -ErrorAction SilentlyContinue | Out-Null
        Remove-ItemProperty -Path $defenderKey -Name "DisableSpecialRunningModes" -ErrorAction SilentlyContinue | Out-Null
        Remove-ItemProperty -Path $defenderKey -Name "DisableRoutinelyTakingAction" -ErrorAction SilentlyContinue | Out-Null
        Remove-ItemProperty -Path $defenderKey -Name "ServiceKeepAlive" -ErrorAction SilentlyContinue | Out-Null
        Remove-ItemProperty -Path "$defenderKey\Real-Time Protection" -Name "DisableBehaviorMonitoring" -ErrorAction SilentlyContinue | Out-Null
        Remove-ItemProperty -Path "$defenderKey\Real-Time Protection" -Name "DisableOnAccessProtection" -ErrorAction SilentlyContinue | Out-Null
        Remove-ItemProperty -Path "$defenderKey\Real-Time Protection" -Name "DisableScanOnRealtimeEnable" -ErrorAction SilentlyContinue | Out-Null
        Remove-ItemProperty -Path "$defenderKey\Signature Updates" -Name "ForceUpdateFromMU" -ErrorAction SilentlyContinue | Out-Null
        Remove-ItemProperty -Path "$defenderKey\SpyNet" -Name "DisableBlockAtFirstSeen" -ErrorAction SilentlyContinue | Out-Null
        
        Write-Host "Microsoft Defender Antivirus has been re-enabled. The following registry keys were modified:" -ForegroundColor Green
        Write-Host "1. DisableAntiSpyware"
        Write-Host "2. DisableRealtimeMonitoring"
        Write-Host "3. DisableAntiVirus"
        Write-Host "4. DisableSpecialRunningModes"
        Write-Host "5. DisableRoutinelyTakingAction"
        Write-Host "6. ServiceKeepAlive"
        Write-Host "7. DisableBehaviorMonitoring (Real-Time Protection)"
        Write-Host "8. DisableOnAccessProtection (Real-Time Protection)"
        Write-Host "9. DisableScanOnRealtimeEnable (Real-Time Protection)"
        Write-Host "10. ForceUpdateFromMU (Signature Updates)"
        Write-Host "11. DisableBlockAtFirstSeen (SpyNet)"

	# Inform the user to manually enable Tamper Protection
        Write-Host "Please remember to manually re-enable Tamper Protection after the restart." -ForegroundColor Yellow
        Write-Host "Go to Windows Security > Virus & threat protection > Virus & threat protection settings." -ForegroundColor Yellow

        # Prompt for computer restart
        Write-Host "Restarting the computer is necessary for the changes to take effect. Do you want to restart now? (Y/N or 'Cancel')"
        $response = Read-Host
        if ($response -eq "Cancel") {
            Write-Host "Script canceled by the user." -ForegroundColor Yellow
            exit
        } elseif ($response -eq "Y") {
            Restart-Computer
        } else {
            Write-Host "Please restart the computer manually later for the changes to take effect" -ForegroundColor Yellow
        }
    } else {
        Write-Host "No changes were made." -ForegroundColor Yellow
    }
} else {
    Write-Host "Microsoft Defender Antivirus is not disabled." -ForegroundColor Yellow
    $response = Read-Host "Do you want to proceed with disabling it? (Y/N or 'Cancel')"
    if ($response -eq "Cancel") {
        Write-Host "Script canceled by the user" -ForegroundColor Yellow
        exit
    } elseif ($response -eq "Y") {
        # Prompt to disable Tamper Protection
        Write-Host "Before proceeding, please turn off Tamper Protection in Windows Security." -ForegroundColor Yellow
        Start-Process "windowsdefender://threatsettings/"
        Read-Host "Once Tamper Protection is turned off, press Enter to continue"

        # Apply registry changes to disable Microsoft Defender silently
        New-ItemProperty -Path $defenderKey -Name "DisableAntiSpyware" -Value 1 -PropertyType DWORD -Force -ErrorAction SilentlyContinue | Out-Null
        New-ItemProperty -Path $defenderKey -Name "DisableRealtimeMonitoring" -Value 1 -PropertyType DWORD -Force -ErrorAction SilentlyContinue | Out-Null
        New-ItemProperty -Path $defenderKey -Name "DisableAntiVirus" -Value 1 -PropertyType DWORD -Force -ErrorAction SilentlyContinue | Out-Null
        New-ItemProperty -Path $defenderKey -Name "DisableSpecialRunningModes" -Value 1 -PropertyType DWORD -Force -ErrorAction SilentlyContinue | Out-Null
        New-ItemProperty -Path $defenderKey -Name "DisableRoutinelyTakingAction" -Value 1 -PropertyType DWORD -Force -ErrorAction SilentlyContinue | Out-Null
        New-ItemProperty -Path $defenderKey -Name "ServiceKeepAlive" -Value 0 -PropertyType DWORD -Force -ErrorAction SilentlyContinue | Out-Null

        # Disable Real-Time Protection settings silently
        New-Item -Path $defenderKey -Name "Real-Time Protection" -Force -ErrorAction SilentlyContinue | Out-Null
        New-ItemProperty -Path "$defenderKey\Real-Time Protection" -Name "DisableBehaviorMonitoring" -Value 1 -PropertyType DWORD -Force -ErrorAction SilentlyContinue | Out-Null
        New-ItemProperty -Path "$defenderKey\Real-Time Protection" -Name "DisableOnAccessProtection" -Value 1 -PropertyType DWORD -Force -ErrorAction SilentlyContinue | Out-Null
        New-ItemProperty -Path "$defenderKey\Real-Time Protection" -Name "DisableScanOnRealtimeEnable" -Value 1 -PropertyType DWORD -Force -ErrorAction SilentlyContinue | Out-Null

        # Disable Signature Updates silently
        New-Item -Path $defenderKey -Name "Signature Updates" -Force -ErrorAction SilentlyContinue | Out-Null
        New-ItemProperty -Path "$defenderKey\Signature Updates" -Name "ForceUpdateFromMU" -Value 0 -PropertyType DWORD -Force -ErrorAction SilentlyContinue | Out-Null

        # Disable SpyNet silently
        New-Item -Path $defenderKey -Name "SpyNet" -Force -ErrorAction SilentlyContinue | Out-Null
        New-ItemProperty -Path "$defenderKey\SpyNet" -Name "DisableBlockAtFirstSeen" -Value 1 -PropertyType DWORD -Force -ErrorAction SilentlyContinue | Out-Null

        Write-Host "Microsoft Defender Antivirus has been disabled. The following registry keys were changed:" -ForegroundColor Green
        Write-Host "1. DisableAntiSpyware"
        Write-Host "2. DisableRealtimeMonitoring"
        Write-Host "3. DisableAntiVirus"
        Write-Host "4. DisableSpecialRunningModes"
        Write-Host "5. DisableRoutinelyTakingAction"
        Write-Host "6. ServiceKeepAlive"
        Write-Host "7. DisableBehaviorMonitoring (Real-Time Protection)"
        Write-Host "8. DisableOnAccessProtection (Real-Time Protection)"
        Write-Host "9. DisableScanOnRealtimeEnable (Real-Time Protection)"
        Write-Host "10. ForceUpdateFromMU (Signature Updates)"
        Write-Host "11. DisableBlockAtFirstSeen (SpyNet)"

        # Prompt for computer restart
        Write-Host "Restarting the computer is necessary for the changes to take effect. Do you want to restart now? (Y/N or 'Cancel')"
        $response = Read-Host
        if ($response -eq "Cancel") {
            Write-Host "Script canceled by the user." -ForegroundColor Yellow
            exit
        } elseif ($response -eq "Y") {
            Restart-Computer
        } else {
            Write-Host "Please restart the computer manually later for the changes to take effect." -ForegroundColor Yellow
        }
    } else {
        Write-Host "No changes were made." -ForegroundColor Yellow
    }
}
